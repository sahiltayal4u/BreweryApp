package com.interviewapp.breweryapp.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.google.common.truth.Truth.assertThat

import com.interviewapp.breweryapp.rest.BreweryRepository
import com.interviewapp.breweryapp.utils.UIState
import com.interviewapp.breweryapp.view.breweryList.BreweryViewModel
import io.mockk.clearAllMocks
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class BreweryViewModelTest {


    @get:Rule
    var rule = InstantTaskExecutorRule()

    private val testDispatcher = UnconfinedTestDispatcher()

    private val mockRepository = mockk<BreweryRepository>(relaxed = true)

    private lateinit var target: BreweryViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        target = BreweryViewModel(mockRepository)
    }

    @After
    fun shutdown() {
        clearAllMocks()
        Dispatchers.resetMain()
    }

    @Test
    fun `get brewery details when trying to load from server returns loading state`() {
        // Assign
        val stateList = mutableListOf<UIState>()
        target.responseState.observeForever {
            stateList.add(it)
        }
        // Action
        target.getBreweryDetails()

        // Assert
        assertThat(stateList).isNotEmpty()
        assertThat(stateList).hasSize(1)
        assertThat(stateList[0]).isInstanceOf(UIState.LOADING::class.java)
    }

    @Test
    fun `get brewery details trying to load from server error state`() {
        // Assign
        every{ mockRepository.responseFlow} returns MutableStateFlow(UIState.ERROR(Exception("Error")))
        val stateList = mutableListOf<UIState>()
        target.responseState.observeForever {
            stateList.add(it)
        }

        // Action
        target.getBreweryDetails()

        // Assertion
        assertThat(stateList).isNotEmpty()
        assertThat(stateList).hasSize(2)
        assertThat(stateList[0]).isInstanceOf(UIState.LOADING::class.java)
        assertThat(stateList[1]).isInstanceOf(UIState.ERROR::class.java)
    }

}