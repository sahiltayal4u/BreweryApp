package com.interviewapp.breweryapp.view.breweryDetails

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.interviewapp.breweryapp.databinding.FragmentBreweryDetailsBinding
import com.interviewapp.breweryapp.model.BreweryItem

const val ARG_BREWERY = "breweryitem"

class BreweryDetailsFragment : Fragment() {

    private val binding by lazy {
        FragmentBreweryDetailsBinding.inflate(layoutInflater)
    }

    private var breweryitem: BreweryItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            breweryitem = it.getSerializable(ARG_BREWERY) as BreweryItem
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        breweryitem?.let { item ->
            binding.nameView.text = "Name: " + item.name
            binding.addressView.text = "Address: " + item.street + ", " + item.city
            binding.countyView.text = "Country: " + item.countyProvince?.toString()
            binding.countryView.text = "Country: " + item.country
            binding.postalView.text = "Postal: " + item.postalCode
            binding.breweryView.text = "Brewery: " + item.breweryType
            binding.street.text = "street: " + item.street
            binding.longitude.text = "longitude: " + item.longitude
            binding.latitude.text = "latitude: " + item.latitude
            binding.phone.text = "phone: " + item.phone
            binding.websiteUrl.text = "websiteUrl: " + item.websiteUrl
        }
        return binding.root
    }
}