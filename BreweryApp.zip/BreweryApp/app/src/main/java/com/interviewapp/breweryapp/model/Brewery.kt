package com.interviewapp.breweryapp.model


class Brewery : ArrayList<BreweryItem>()