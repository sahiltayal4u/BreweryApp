package com.interviewapp.breweryapp.view.breweryList

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.interviewapp.breweryapp.rest.BreweryRepository
import com.interviewapp.breweryapp.utils.UIState
import dagger.hilt.android.lifecycle.HiltViewModel
import io.reactivex.disposables.CompositeDisposable
import kotlinx.coroutines.*
import javax.inject.Inject

@HiltViewModel
class BreweryViewModel @Inject constructor(private val breweryRepository: BreweryRepository
) : ViewModel() {
    private val coroutineDispatcher: CoroutineDispatcher = Dispatchers.IO
    private val compositeDisposable = CompositeDisposable()
    private var _responseState: MutableLiveData<UIState> = MutableLiveData(UIState.LOADING())
    val responseState: LiveData<UIState> = _responseState

    private fun collectState() {
        viewModelScope.launch(coroutineDispatcher) {
            breweryRepository.responseFlow.collect { uistate ->
                _responseState.postValue(uistate)
            }
        }
    }

    fun getBreweryDetails() {
        collectState()
        breweryRepository.getBreweries(compositeDisposable)
    }


    override fun onCleared() {
        compositeDisposable.dispose()
        super.onCleared()
    }
}