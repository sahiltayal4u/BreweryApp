package com.interviewapp.breweryapp.view.breweryList

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.interviewapp.breweryapp.R
import com.interviewapp.breweryapp.adapter.BreweryAdapter
import com.interviewapp.breweryapp.databinding.FragmentBreweryBinding
import com.interviewapp.breweryapp.model.Brewery
import com.interviewapp.breweryapp.model.BreweryItem
import com.interviewapp.breweryapp.utils.UIState
import com.interviewapp.breweryapp.utils.visible
import com.interviewapp.breweryapp.view.breweryDetails.ARG_BREWERY
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BreweryFragment : Fragment() {

    private val viewModel: BreweryViewModel by viewModels<BreweryViewModel>()
    private var breweryAdapter = BreweryAdapter {item -> onAdapterItemClick(item)}

    private val binding by lazy{
        FragmentBreweryBinding.inflate(layoutInflater)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding.breweryList.apply {
            layoutManager=LinearLayoutManager(activity)
            adapter=breweryAdapter
        }
        viewModel.responseState.observe(viewLifecycleOwner) { uistate ->
            when (uistate) {
                is UIState.LOADING -> {
                    binding.progressbarBrewery.visibility =
                        if (uistate.isLoading) View.VISIBLE else View.GONE
                }
                is UIState.SUCCESS -> {
                    //binding.progressbarBrewery.gone()
                    Log.e("123121TAG", "onCreateView: "+ uistate.response)
                    val response = uistate.response as Brewery
                    Log.e("123121TAG", "onCreateView: "+ uistate.response)
                    breweryAdapter.loadBrewery(response)
                }
                is UIState.ERROR -> {
                    binding.progressbarBrewery.visible()
                    Log.e("123121TAG", "onCreateView: "+uistate.error.localizedMessage.toString() )
                    Toast.makeText(activity, uistate.error.localizedMessage, Toast.LENGTH_LONG)
                        .show()
                }
            }
        }
        viewModel.getBreweryDetails()
        return binding.root
    }
    fun onAdapterItemClick(item: BreweryItem) {
        val bundle= bundleOf()
        bundle.putSerializable(ARG_BREWERY,item)
        findNavController().navigate(R.id.action_breweryListFragment_to_breweryDetailFragment,bundle)
    }
}