package com.interviewapp.breweryapp.rest

import com.interviewapp.breweryapp.model.Brewery
import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Query

interface BreweryAppServices {

    @GET(PATH_BREWERIES)
    fun getBreweries(
        @Query(QUERU_DIST) dist: String = "60.164743,10.331000"
    ): Single<Brewery>

    companion object{
        //https://api.openbrewerydb.org/breweries?by_dist=38.8977,77.0365
        const val BASE_URL = "https://api.openbrewerydb.org/"
        private const val PATH_BREWERIES = "breweries"
        private const val QUERU_DIST = "by_dist"
    }

}