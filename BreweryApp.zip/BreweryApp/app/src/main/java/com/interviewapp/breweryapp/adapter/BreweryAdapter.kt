package com.interviewapp.breweryapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.interviewapp.breweryapp.databinding.LayBreweryBinding
import com.interviewapp.breweryapp.model.BreweryItem

class BreweryAdapter(val adapterOnClick : (BreweryItem) -> Unit): RecyclerView.Adapter<BookingViewHolder>() {
    private val breweryItems: MutableList<BreweryItem> = mutableListOf()

    fun loadBrewery(breweryItems:MutableList<BreweryItem>){
        this.breweryItems.addAll(breweryItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookingViewHolder {
        return BookingViewHolder(LayBreweryBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: BookingViewHolder, position: Int) {
        holder.updateView(breweryItems[position])
        holder.itemView.setOnClickListener {  adapterOnClick(breweryItems[position])}
    }

    override fun getItemCount(): Int {
        return breweryItems.size
    }
}

class BookingViewHolder(itemView: LayBreweryBinding) :
    RecyclerView.ViewHolder(itemView.root) {

    private val binding = itemView
    fun updateView(item:BreweryItem){
        binding.nameView.text=item.name
        binding.addressView.text= item.street+", " +item.city
        binding.countyView.text=item.countyProvince?.toString()
        binding.countryView.text=item.country
        binding.postalView.text= item.postalCode
        binding.breweryView.text=item.breweryType
    }
}