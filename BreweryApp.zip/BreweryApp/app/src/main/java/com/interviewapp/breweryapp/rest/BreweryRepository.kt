package com.interviewapp.breweryapp.rest



import com.interviewapp.breweryapp.utils.UIState
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import retrofit2.Response

interface BreweryRepository {
   val responseFlow: StateFlow<UIState>
   fun getBreweries(compositeDisposable:CompositeDisposable)
}

class BreweryRepositoryImpl(
   private val apiService: BreweryAppServices
):BreweryRepository{

   private val _responseFlow: MutableStateFlow<UIState> = MutableStateFlow(UIState.LOADING())
   override val responseFlow: StateFlow<UIState>
      get() = _responseFlow

   override fun getBreweries(compositeDisposable: CompositeDisposable) {
      _responseFlow.value=(UIState.LOADING())
      try {
         compositeDisposable.add(
            apiService.getBreweries()
               .observeOn(AndroidSchedulers.mainThread())
               .subscribeOn(Schedulers.io())
               .subscribe({
                  _responseFlow.value=(UIState.SUCCESS(it))
               }, {
                  _responseFlow.value=(UIState.ERROR(it))
               }))
      } catch (e: Exception) {
         _responseFlow.value=(UIState.ERROR(e))
      }
   }

}