package com.interviewapp.breweryapp.utils

sealed class UIState{
    class LOADING(val isLoading:Boolean=true) : UIState()
    class SUCCESS(val response: Any): UIState()
    class ERROR(val error:Throwable): UIState()
}